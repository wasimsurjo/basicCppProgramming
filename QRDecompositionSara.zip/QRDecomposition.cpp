#include<iostream>
#include<fstream>
#include<vector>
#include<ostream>
#include <algorithm>
#include<iomanip>
#include<math.h>
using namespace std;

class Vector_operator;

typedef vector<double>Vector;
typedef vector<Vector>Matrix;
typedef vector<Vector_operator>Matrix_Operator;


int factorial(int a);
Matrix InvertM(Matrix a);

class Vector_operator{
public:
	Vector_operator()
	{		Vector a;
		for(int i = 0; i < 3; i++)
			a.push_back(0);
		itsVector = a;    }

	Vector_operator(Vector& a){ itsVector = a;}
	~Vector_operator(){};
	void setVector(const Vector& a){ itsVector = a;}
	Vector getVector(){ return itsVector;}

	Vector_operator operator+(const Vector_operator& a)
	{		Vector b = a.itsVector;
		Vector c = a.itsVector;
		for(int i = 0; i < b.size(); i++)
			c[i] = itsVector[i] + b[i];
		Vector_operator z(c);
		return z;	}

	Vector_operator operator-(const Vector_operator& a)
	{		Vector b = a.itsVector;
		Vector c = a.itsVector;
		for(int i = 0; i < b.size(); i++)
			c[i] = itsVector[i] - b[i];
		Vector_operator z(c);
		return z;	}

	double operator*(const Vector_operator& a)
	{		Vector b = a.itsVector;
		double res = 0;
		for(int i = 0; i < b.size(); i++)
			res += (itsVector[i] * b[i]);
		return res;	}

	Vector_operator operator*(const double& x)
	{		Vector b = itsVector;
		for(int i = 0; i < b.size(); i++)
			b[i] *= x;
		Vector_operator w(b);
		return w;	}

	double operator[](int x)
	{
		Vector b = itsVector;
		return b[x];
	}

	double sq_norm()
	{		double res = 0;
		for(int i = 0; i < itsVector.size(); i++)
			res += (itsVector[i] * itsVector[i]);
		return res;	}

	friend
	ostream& operator<<( ostream& xout, const Vector_operator& v)
	{		Vector a = v.itsVector;
		for(int i = 0; i < a.size(); i++)
		{			xout << " element [" << i << "] = " << a[i] << endl;		}
		return xout;	}

	Matrix_Operator setMatrix_Operator( Matrix a)
	{		Matrix_Operator b;
		for(int i = 0; i < a.size(); i++)
		{
			Vector_operator v(a[i]);
			b.push_back(v);
		}
		return b;
	}

	Matrix getMatrix( Matrix_Operator a)
	{
		Matrix b;
		Vector v;
		for(int i = 0; i < a.size(); i++)
		{
			v = a[i].getVector();
			b.push_back(v);
		}
		return b;
	}

private:
	Vector itsVector;
};


int main()
{
    ofstream outFile;
    outFile.open("solution.txt");

	Vector v1;	Vector v2;	Vector c;	double x;

	Vector_operator v(v1);
	Vector_operator w(v2);
	x = v * w;
	Vector_operator y(v1);
	y = v * x;
	c = y.getVector();

	double z = w.sq_norm();

	Vector_operator u(v1);
	u = v + w;
	c = u.getVector();

	int i;
	int counter = 0;
	int mcount = 0;
	cout << "\nWelcome! This Is QR Decomposition Of A 3x3 Matrix! :\n";
	mcount=3;

	cout << "\n";
	Vector row(mcount);
	Vector determinant;
	Matrix a;
	int product = 1;
	int determ = 0;
	int ve1 = 0;

    std::fstream myfile("data.txt", std::ios_base::in);

    float d1,d2,d3,d4,d5,d6,d7,d8,d9;

    myfile >> d1 >> d2 >> d3 >> d4 >> d5 >> d6>> d7 >> d8 >> d9;

    float data[3][3] = {{d1, d2, d3},{d4, d5, d6},{d7,d8,d9}};

    myfile.close();

    cout << "Your Matrix Was Received From 'data.txt' File Successfully! :\n";

	for(i = 0; i < mcount; i++)
	{
		for(int j = 0; j < mcount; j++)
		{
           row[j] = data[i][j];
		}
		a.push_back(row);
	}

	vector<int>vec;
	for(i = 1; i <= mcount; i++)
		vec.push_back(i);
	vector<int>::iterator iter1 = vec.begin();
	vector<int>::iterator iter2 = vec.end();


	for(i = 0; i < factorial(mcount); i++)
	{
		  vector<int>vec1(mcount);
		  copy(vec.begin(), vec.end(), vec1.begin());
		  for(int j = 0; j < (mcount); j++)

		  for(int i = 0; i < vec1.size(); i++)
		  {  for(int j = i; j < vec1.size(); j++)
			  {
				  if(vec1[j]<vec1[i])
					  counter++;
			  }  }

		  for(int w = 0; w < mcount; w++)
		  {
			  ve1 = (vec1[w])-1;
			  product *= (a[w][ve1]);
		  }
		  if(counter%2!=0)
			  product = (- product);

		  determinant.push_back(product);
          counter = 0;
		  product = 1;
		  next_permutation(iter1, iter2);	}

	for(int x = 0; x < determinant.size(); x++)
	{
		determ += determinant[x];
	}

	for(i = 0; i < mcount; i++)//print the matrix
	{
		cout << endl;
		for(int j = 0; j < mcount; j++)
		{
			cout << a[i][j] << " ";
		}
	}
	cout <<"\n\n"<< endl;


	cout << "The determinant is : "<<determ<<"!\n"<<endl;
	if(determ!=0) cout << "Here, the determinant is not zero. This means QR Decomposition is possible. \n";
	else cout << "Unfortunately, the determinant is zero. So, no QR decomposition possible! \n\n";

	cout << "\nCheck The 'solution.txt' File For The Solution With 2 Digits After The Decimal(Formatted)\n"<<endl;

	Matrix e;
	Vector d;
	for(int j = 0; j < (a[0].size()); j++)
	{
		for(int i = 0; i < a.size(); i++)
		{
			d.push_back(a[i][j]);
		}
		e.push_back(d);
		d.clear();
	}


	Vector row1;
	Matrix q,f;
	for(int i = 0; i < a.size(); i++)
	{
		for(int j = 0; j < a.size(); j++)
		{
			row1.push_back(0);
		}
		q.push_back(row1);
		f.push_back(row1);
	 }
	Matrix_Operator qz, fz, ez;
	qz = v.setMatrix_Operator(q);
	fz = v.setMatrix_Operator(f);
	ez = v.setMatrix_Operator(e);
    for(int i = 0; i < q.size(); i++)
	{
		for(int j =0; j < q.size(); j++)
		{

			if(i==0)
				qz[i] = ez[i];
			if(i!=0)
			{
				if(j==0)
					fz[j].setVector(f[0]);
			    if(j!=0)
			    {
				    fz[j] =   fz[j-1] + ( qz[j-1] * ( ez[i] * qz[j-1] ))* ( 1 / qz[j-1].sq_norm() );
					if(j==i)
					{
						qz[i] = ez[i] - fz[j];
						j = q.size();
					}			    }			}		}

		fz = v.setMatrix_Operator(f);
	}
    Matrix qw;
	qw = v.getMatrix(qz);


	for(int i = 0; i < qz.size(); i++)
	{
		double n = qz[i].sq_norm();
		n = sqrt(n);
		Vector ort; double w;
		for(int j =0; j < (qz[0].getVector()).size(); j++)
		{
			w = (qz[i].getVector())[j] /=  n;
			ort.push_back(w);
		}
		qz[i].setVector(ort);
	}
	qw = v.getMatrix(qz);

	Matrix r = f;
	Matrix_Operator rz;
	rz = v.setMatrix_Operator(r);
	for(int i = 0; i < ez.size(); i++)
	{
		Vector tria; double w;
		for(int j =0; j < ez.size(); j++)
		{{
				w = ((rz[i]).getVector())[j] = ez[i] * qz[j];
				tria.push_back(w);
			}
		}
		rz[i].setVector(tria);
	}
	r = v.getMatrix(rz);

	Matrix Q, R;
	Q = InvertM(qw);
	R = InvertM(r);

	outFile << "Here Are The Results: \n\n";

	outFile << "The Q matrix is :\n";
    for(i = 0; i < mcount; i++)
	{
		outFile <<"\n";
		for(int j = 0; j < mcount; j++)
		{
			outFile << fixed << setprecision(2) << Q[i][j] << " ";
		}
	}
	outFile <<"\n\n";
	outFile << "The R matrix is :\n";

       for(i = 0; i < mcount; i++)//print the matrix
	{
		outFile <<"\n";
		for(int j = 0; j < mcount; j++)
		{
			outFile <<  R[i][j] << " ";
		}
	}
   outFile.close();
	return 0;
}

   Matrix InvertM(Matrix a)
   {
	   Matrix e;
	   Vector d;
	   for(int j = 0; j < (a[0].size()); j++)
	   {
		  for(int i = 0; i < a.size(); i++)
		  {
			  d.push_back(a[i][j]);
		  }
		  e.push_back(d);
		  d.clear();
	   }
	   return e;
   }

   int factorial(int a)
   {
	    if(a<=1)
		   return a;
	    return (a * factorial(a - 1));
   }
